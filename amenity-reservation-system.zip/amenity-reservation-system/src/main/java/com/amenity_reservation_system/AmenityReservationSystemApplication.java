package com.amenity_reservation_system;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class AmenityReservationSystemApplication {

    public static void main(final String[] args) {
        SpringApplication.run(AmenityReservationSystemApplication.class, args);
    }

}
